# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:49:37.785Z

## Consent Metadata
- Version: 1.1
- User: user-P
- Note: note-P600

## Proof Integrity
- Signature: `3af10335e7b7b92f895c6e09666776998bc9bee0cabc73c600dd70f8d8372906`
- Verified: true

## Ledger Record
- Ledger Hash: `7ab6169a6b27aaaa941c5520eab79085c558f0ea9d583412184a31779bdf2b8f`
- Published: 2025-10-31T10:49:37.784Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.