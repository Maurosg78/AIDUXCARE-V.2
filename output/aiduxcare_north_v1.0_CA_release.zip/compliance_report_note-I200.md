# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:24:39.610Z

## Consent Metadata
- Version: 1.1
- User: user-I
- Note: note-I200

## Proof Integrity
- Signature: `0c3c153127c80dad746ee8b07d031516a91cfe7d6cf486633e7454dd231d2ea2`
- Verified: true

## Ledger Record
- Ledger Hash: `d0a099a9eb271542f5720a9ac09e14d74929173d97e0591e1d58972f68b40482`
- Published: 2025-10-31T10:24:39.609Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.