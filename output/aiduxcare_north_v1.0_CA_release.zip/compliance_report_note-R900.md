# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:12:40.659Z

## Consent Metadata
- Version: 1.1
- User: user-R
- Note: note-R900

## Proof Integrity
- Signature: `26041fd5a135657cea488949e5c55233ddcffa518c2ea896dd2a815551313f34`
- Verified: true

## Ledger Record
- Ledger Hash: `6e1daf0a1d0ec8dee7faa274c32536b198e17f06906fcc86a7ad84706a172738`
- Published: 2025-10-31T10:12:40.658Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.