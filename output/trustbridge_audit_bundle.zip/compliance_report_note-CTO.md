# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:08:04.953Z

## Consent Metadata
- Version: 1.1
- User: user-A
- Note: note-CTO

## Proof Integrity
- Signature: `e4980779beb4379ec7a63753ee88f101117bfdd46cc92c7d53446d9a8e882385`
- Verified: true

## Ledger Record
- Ledger Hash: `ff82e9a2cac0396b4e14695abc3fef1882136938a73c1b4b53f2b77b1c36bccc`
- Published: 2025-10-31T10:08:04.953Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.