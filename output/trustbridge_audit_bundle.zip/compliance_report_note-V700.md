# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:21:56.558Z

## Consent Metadata
- Version: 1.1
- User: user-V
- Note: note-V700

## Proof Integrity
- Signature: `91b3107ba5d5a9a1af3a604fe0392553b49a5999ab833a53dee923e5dd915f72`
- Verified: true

## Ledger Record
- Ledger Hash: `0b8bc59f37ec97a61353d5a52f5ff57c79ece95e706c3fcd099a246966e476ec`
- Published: 2025-10-31T10:21:56.557Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.