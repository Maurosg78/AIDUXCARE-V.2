# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:00:34.075Z

## Consent Metadata
- Version: 1.1
- User: user-CA
- Note: note-900

## Proof Integrity
- Signature: `19864890c7d0b55f7c92025db3ff5765ad582b1fedf96efb5a0fa9e0280e7c09`
- Verified: true

## Ledger Record
- Ledger Hash: `f7a697c6293459c4f3eb6b5ebc3ba5611b6a757e733176436f8119600e34cec7`
- Published: 2025-10-31T10:00:34.074Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.