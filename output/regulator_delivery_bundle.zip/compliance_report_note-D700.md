# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:26:49.898Z

## Consent Metadata
- Version: 1.1
- User: user-D
- Note: note-D700

## Proof Integrity
- Signature: `fb54eaa05ae941e3e22bfff7edc90200154e5a68ddb5b662209cbd0dd1125a6d`
- Verified: true

## Ledger Record
- Ledger Hash: `73cb0b52b08202bf0ab902f8bdc9dc23e5b2d6de02d513217deb10454e99212d`
- Published: 2025-10-31T10:26:49.898Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.