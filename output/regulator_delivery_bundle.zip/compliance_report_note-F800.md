# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:43:03.353Z

## Consent Metadata
- Version: 1.1
- User: user-F
- Note: note-F800

## Proof Integrity
- Signature: `4b8db866e2830ff2944016a24ff03e4d79226b1e4ea9f7ae1b3695a34442e604`
- Verified: true

## Ledger Record
- Ledger Hash: `b68318aa841e70cbc145d35cf72e2c5132823281b88c476c0ae96edf0902c5db`
- Published: 2025-10-31T10:43:03.352Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.