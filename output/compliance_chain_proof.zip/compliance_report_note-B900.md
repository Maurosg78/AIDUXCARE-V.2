# 🧾 AiDuxCare — Compliance Report
**Jurisdiction:** Ontario, Canada  
**Generated:** 2025-10-31T10:33:50.560Z

## Consent Metadata
- Version: 1.1
- User: user-B
- Note: note-B900

## Proof Integrity
- Signature: `fb01a7c1ee659a54e6c5ba64e8794e7a878a459fa83154b76e7b82ea460e0444`
- Verified: true

## Ledger Record
- Ledger Hash: `5468bf0beabcc03900604ad9cd3fe41dc5acd810d9dc5e36c73f325435e6b147`
- Published: 2025-10-31T10:33:50.560Z
- Verified: true

---

**Frameworks:** PHIPA | PIPEDA | CPO Ontario  
✅ Verified and audit-ready.