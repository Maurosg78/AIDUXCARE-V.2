# Reglas de contribución

- No se permite `any`
- Todo debe estar tipado
- Cada PR debe pasar linting, testing y revisión
- Usar carpetas por responsabilidad (core, features, shared, etc.)
