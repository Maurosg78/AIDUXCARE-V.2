# AIDUXCARE V.2

Asistente clínico inteligente rediseñado desde cero.
