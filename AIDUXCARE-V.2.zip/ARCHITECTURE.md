# Arquitectura de AiDuxCare V.2

Diseñado siguiendo un enfoque MCP-first, modular y basado en agentes con memoria contextual y persistente.
