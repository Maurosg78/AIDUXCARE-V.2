import React from "react";

export default function PatientConsentPage() {
  return <div>Patient Consent – Placeholder</div>;
}
