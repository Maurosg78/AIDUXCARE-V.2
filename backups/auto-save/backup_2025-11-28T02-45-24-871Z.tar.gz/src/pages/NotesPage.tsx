export const NotesListPage = () => <div>Notes List</div>;
export const NoteDetailPage = () => <div>Note Detail</div>;
