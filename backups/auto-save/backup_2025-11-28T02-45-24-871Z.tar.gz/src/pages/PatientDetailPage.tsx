export const PatientDetailPage = () => <div>Patient Detail</div>;
