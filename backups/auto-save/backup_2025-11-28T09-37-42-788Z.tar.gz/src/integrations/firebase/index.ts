export { isFirebaseEnabled, getAuthBridge } from "./firebase";
export type { FirebaseAuth } from "./firebase";
