// @ts-nocheck
// Archivo eliminado por decisión de merge enterprise. No restaurar. 