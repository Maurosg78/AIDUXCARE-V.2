import React from 'react';

export default function ProfessionalOnboardingPage() {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>Professional Onboarding</h1>
      <p>Wizard setup coming soon...</p>
    </div>
  );
}
