import React from "react";
import ProfessionalOnboardingPage from "../../pages/ProfessionalOnboardingPage";

export function RegisterPage() {
  return <ProfessionalOnboardingPage />;
}

export default RegisterPage;
