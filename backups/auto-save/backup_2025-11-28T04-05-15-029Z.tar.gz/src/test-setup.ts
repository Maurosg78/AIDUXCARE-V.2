/**
 * Vitest Test Setup
 * 
 * Global setup for all tests
 */
import '@testing-library/jest-dom/vitest';

